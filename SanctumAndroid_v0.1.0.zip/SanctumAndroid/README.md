# Sanctum Android starter (v0.1.0)

This is the first Android Studio source scaffold for Sanctum.

## Included
- Kotlin + Jetpack Compose dark interface
- Dashboard, History, Devices and Settings tabs
- Demo-mode placeholder readings
- Home/Away UI toggle
- Android internet/network/notification permissions
- Local + remote connectivity architecture notes in the Devices screen

## Open
1. Extract this ZIP.
2. Open the `SanctumAndroid` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Run the `app` configuration on an Android device or emulator.

## Current limitations
This is the UI foundation, not a hardware-connected release yet. Sensor readings are sample values.
ESP32 networking, secure remote relay, persistent Room history, notification delivery, and APK validation are next steps.
No mains switching is implemented. Keep the prototype low-voltage and retain all safety decisions on the ESP32.
