package com.sanctum.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF090F1C)
private val Surface = Color(0xFF131D2D)
private val Surface2 = Color(0xFF1A2940)
private val Accent = Color(0xFF55A6FF)
private val Muted = Color(0xFF91A2B8)
private val Green = Color(0xFF39D98A)
private val Amber = Color(0xFFFFC857)
private val Red = Color(0xFFFF5D6C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SanctumApp() }
    }
}

@Composable
fun SanctumApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var awayMode by remember { mutableStateOf(false) }
    var demoMode by remember { mutableStateOf(true) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = Surface,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Surface, contentColor = Muted) {
                    val items = listOf("Home", "History", "Devices", "Settings")
                    val icons = listOf(Icons.Default.Home, Icons.Default.History, Icons.Default.Memory, Icons.Default.Settings)
                    items.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                indicatorColor = Surface2,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> DashboardScreen(Modifier.padding(padding), awayMode, { awayMode = it }, demoMode)
                1 -> HistoryScreen(Modifier.padding(padding))
                2 -> DevicesScreen(Modifier.padding(padding), demoMode)
                else -> SettingsScreen(Modifier.padding(padding), demoMode, { demoMode = it })
            }
        }
    }
}

@Composable
fun DashboardScreen(modifier: Modifier, away: Boolean, onAwayChange: (Boolean) -> Unit, demo: Boolean) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("SANCTUM", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Room overview", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.background(Surface2, CircleShape).padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(Green, CircleShape))
                        Spacer(Modifier.width(7.dp))
                        Text(if (demo) "DEMO MODE" else "LIVE MODE", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF12372F)), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Color(0xFF1C6049), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Green, modifier = Modifier.size(27.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ROOM STATUS", color = Color(0xFF9ADFC1), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("SAFE", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Text("All monitored readings are normal", color = Color(0xFFB9DCCB), fontSize = 12.sp)
                    }
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Green)
                }
            }
        }
        item {
            Text("LIVE SENSORS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SensorCard("Temperature", "28°C", "DHT11", Icons.Default.Thermostat, Modifier.weight(1f))
                SensorCard("Smoke level", "Normal", "MQ-2", Icons.Default.Cloud, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SensorCard("Motion", "None", "PIR SENSOR", Icons.Default.Sensors, Modifier.weight(1f))
                SensorCard("Exhaust fan", "OFF", "RELAY 1", Icons.Default.Air, Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Security mode", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Motion alerts are enabled in Away mode", color = Muted, fontSize = 11.sp)
                        }
                        Switch(checked = away, onCheckedChange = onAwayChange)
                    }
                    Text(if (away) "AWAY MODE" else "HOME MODE", color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Recent activity", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("View all", color = Accent, fontSize = 12.sp)
            }
            ActivityRow("System started", "All sensors initialized", "Just now", Green)
            ActivityRow("Room status checked", "No abnormal readings", "1 min ago", Accent)
        }
        item {
            Text("Prototype dashboard · Sample readings only", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun SensorCard(title: String, value: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(21.dp))
            Text(title, color = Muted, fontSize = 11.sp)
            Text(value, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun ActivityRow(title: String, detail: String, time: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).background(color, CircleShape))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
        Text(time, color = Muted, fontSize = 10.sp)
    }
}

@Composable
fun HistoryScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("History", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Your room's recent activity", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        listOf(
            Triple("System started", "Normal · Sensors initialized", "Today"),
            Triple("Room status checked", "Safe · No abnormal readings", "Today"),
            Triple("Demo mode enabled", "Sample sensor data active", "Today")
        ).forEach { row ->
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(row.first, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(row.second, color = Muted, fontSize = 12.sp)
                    Text(row.third, color = Accent, fontSize = 10.sp)
                }
            }
        }
        Text("History currently uses placeholder entries. Persistent sensor history will be added in the next development phase.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun DevicesScreen(modifier: Modifier, demo: Boolean) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Devices", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Manage your Sanctum controller", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Memory, contentDescription = null, tint = Accent, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Sanctum ESP32", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(if (demo) "Not connected · Demo mode" else "Waiting for connection setup", color = Muted, fontSize = 11.sp)
                    }
                    Box(Modifier.size(9.dp).background(Amber, CircleShape))
                }
                HorizontalDivider(Modifier.padding(vertical = 14.dp), color = Surface2)
                DeviceInfo("Connection", "Not configured")
                DeviceInfo("Protocol", "To be implemented")
                DeviceInfo("Last update", "No live data yet")
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Connectivity plan", color = Color.White, fontWeight = FontWeight.Bold)
        Text("Local Wi-Fi: direct communication with the ESP32 on your home network. Remote access: secure internet relay through an authenticated cloud service. Local safety logic will continue working if either connection is unavailable.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun DeviceInfo(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
fun SettingsScreen(modifier: Modifier, demo: Boolean, onDemoChange: (Boolean) -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Settings", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Customize your Sanctum experience", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Demo mode", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Use sample readings without ESP32 hardware", color = Muted, fontSize = 11.sp)
                    }
                    Switch(checked = demo, onCheckedChange = onDemoChange)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("About Sanctum", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Version 0.1.0 · Android prototype", color = Muted, fontSize = 12.sp)
                Text("This prototype is not a certified fire or security device. Always rely on certified safety equipment.", color = Amber, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }
    }
}
